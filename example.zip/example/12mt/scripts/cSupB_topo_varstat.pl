#!/usr/bin/perl
use strict;
use warnings;
# the statistics of the node variants and SNVs
open(IN,"cSupB_topo.txt");
my%source2var;
my%pos2var;
my@varcount = (0,0,0,0);#node_variant; format:SNP,del,ins,Indel
my@posvarcount= (0,0,0,0);#SNV; format:SNP,del,ins,Indel
my$count1 = 0;
foreach my$line(<IN>){
	chomp$line;
	my@info = split(/\t/,$line);
	my$nodes = $info[4];
	my$vartype = $info[8];
	my@sourcesink = split(/:/,$nodes);
	my$source = $sourcesink[0];
	my$sourcepos = $info[2];
	my$gap = abs($info[7]);
	if(!exists($source2var{$source})){
		$source2var{$source} = $vartype;
		$varcount[$vartype-1]++;
		if($vartype == 1 && $gap > 0){
			print "var=1&gap>0: $source\n";
		}
		$count1++;
	}
	if($gap == 0 && !exists($pos2var{$sourcepos+1})){
		$posvarcount[0]++;
		$pos2var{$sourcepos+1} = 1;
	}
	if($gap > 0){
		for(my $i = 0;$i < $gap;$i++){
			if(!exists($pos2var{$sourcepos+$i+1})){
				$pos2var{$sourcepos+$i+1} = 2;
				if($source2var{$source} == 2){
					$posvarcount[1]++;
				}elsif($source2var{$source} == 3){
					$posvarcount[2]++;
				}else{
					$posvarcount[3]++;
				}
			}else{
				if($pos2var{$sourcepos+$i+1}== 1){
					$pos2var{$sourcepos+$i+1} = 2;
					$posvarcount[0]--;
					if($source2var{$source} == 2){
						$posvarcount[1]++;
					}elsif($source2var{$source} == 3){
						$posvarcount[2]++;
					}else{
						$posvarcount[3]++;
					}
				}
			}
		}
	}
	
}
print "var_count:@varcount\n";
print "SNV_count:@posvarcount\n";
open(IN2,"offsetinfo.txt");
#print "count1:$count1\n";
my$count2 = 0;
my$len1 = keys %source2var;
#print "$len1\n";
my$count3 = 0;
foreach my$line(<IN2>){
	chomp$line;
	my@info = split(/\t/,$line);
	my$node = $info[0];
	my$gap = $info[3];
	
	if($gap > 0){
		$count2++;
#		print "$node:$gap:$source2var{$node};";
		if($source2var{$node} > 0){
			$count3++;
			#print "$node\n";
		}
	}
}
#print "$count2\n";
#print "$count3\n";
