#!/usr/bin/perl
use strict;
use warnings;
open(IN1,"refcutseqs.txt") or die "can't find refcutseqs.txt\n";
open(IN2,"filelist.txt") or die "can't find fasta files\n";
my@refcutseqs = <IN1>;
my$kmer = 18;
my$cutsize = @refcutseqs;
my$initialhead = "GATCACAGGTCTATCACCCTATTAACCACTCA";
my$initialtail = "CACACGTTCCCCTTAAATAAGACATCACGATG";
my$taillen = length($initialtail);
my$head = substr($initialhead,0,$kmer);
my$tail = substr($initialtail,$taillen-$kmer,$kmer);
print "$head\n$tail\n";
for(my$i = 1;$i < $cutsize+2;$i++){
	my$dirname = "dir$i";
	qx(mkdir $dirname);
}
foreach my$file(<IN2>){
	chomp$file;
	open(IN3,"$file") or die "can't find the $file\n";
#	print "$file\n";
	my$orgin = $/;
	$/ = ">";
	
	foreach my$block(<IN3>){
		#if($block =~ /(.*?)\n([\s\w[a-zA-Z]]+)/){
		my@samplecutpos;
		if($block =~ /(.*?)\s.*?\n([a-zA-Z\s]+)/){
			my$name = $1;
			my$seq = $2;
			$seq =~ tr/\n//d;
			#print "$file:$seq\n";
			for(my$i = 0;$i < $cutsize;$i++){
				chomp$refcutseqs[$i];
				my@info = split(/\t/,$refcutseqs[$i]);
				my$cutseq = $info[1];
				chomp$cutseq;
				chop$cutseq;
				my$refpos = $info[0];
				my$cutseqlen = length($cutseq);
				my@tmpmappos;
				#print "$seq\n$cutseq\t$cutseqlen\n";
				#if($seq =~ /($cutseq)/){
				while($seq =~ m/($cutseq)/g){
#					print "$cutseq";
					my$end = pos($seq);
					my$start = $end - $cutseqlen + 1;
					my$cutpos = int(($start+$end)/2);
				#	print "$cutpos\n";
					push(@tmpmappos,$cutpos);
				}
				my$tmpdiff = abs($tmpmappos[0] - $refpos);
				my$finalcutpos = $tmpmappos[0];
				my$mappossize = @tmpmappos;
				for(my$j = 1;$j < $mappossize;$j++){
					my$tmpdiff2 = abs($tmpmappos[$j] - $refpos);
					if($tmpdiff2 < $tmpdiff){
						$tmpdiff = $tmpdiff2;
						$finalcutpos = $tmpmappos[$j];
					}
				}
				push(@samplecutpos,$finalcutpos);
			}	
			my$cutnum = @samplecutpos;
			my$seqlen = length($seq);
			my$cutend = $seqlen-1;
			for(my$i = $cutnum-1;$i >=0;$i--){
				my$tmpseq = substr($seq,$samplecutpos[$i],$cutend-$samplecutpos[$i]+1);
				if($cutend == $seqlen-1){
					$tmpseq = "$head"."$tmpseq";
				}else{
					$tmpseq = "$head"."$tmpseq"."$tail";
				}
				$cutend = $samplecutpos[$i]-1;
				my$dirid = $i+2;
				my$dirname2 = "dir$dirid";
				open(OUT,">$dirname2/$file");
				print OUT ">$file\_$dirid\n$tmpseq\n";
				close(OUT);
			}
			open(OUT,">dir1/$file");
			my$tmpseq = substr($seq,0,$cutend+1);
			$tmpseq = "$tmpseq"."$tail";
			print OUT ">$file\_1\n$tmpseq\n";
			close(OUT);
		}

	}
	$/ = $orgin;
}
