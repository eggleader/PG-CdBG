#!/usr/bin/perl
use strict;
use warnings;
my@files = qx(ls *fasta);
open(IN,"newfilelist.txt");
my%name2hap;
open(OUT,">mt.fa");
foreach my$line(<IN>){
	chomp$line;
	my@info = split(/\t/,$line);
	$name2hap{$info[0]} = $info[2];
	
}
foreach my$file(@files){
	chomp$file;
	#print "$file\n";
	open(IN2,$file);
	my$newname = $1 if($file =~ /(.*)\.fasta/);
	#print "$newname\n";
	my$orgin = $/;
	$/ = ">";
	foreach my$block(<IN2>){
		#if($block =~ /($newname).*?\n([ACGT\n]+)/){
		if($block =~ /.*?\n([ACGT\n]+)/){
			#print OUT ">$newname\n$1";
			print OUT ">$name2hap{$newname}\n$1";
		}
	}
	$/ = $orgin;
}

