#!/bin/perl
use strict;
use warnings;
open(IN,"filelist.txt");
open(OUT,">newfilelist.txt");
open(OUT1,">c800weight_label.txt");
my%groupcount;
my%grouplabel;
my$label = 0;
foreach my$line(<IN>){
	chomp$line;
	my@info = split(/\t/,$line);
	my$group = $info[1];
#	print $group;
	if(!exists($groupcount{$info[1]})){
		$groupcount{$info[1]}=1;
		$label+=1;
		$grouplabel{$info[1]} = $label;
	}
	print OUT "$line\t$group\_$groupcount{$info[1]}\t$grouplabel{$info[1]}\n";
	print OUT1 "$grouplabel{$info[1]}\n";
	$groupcount{$info[1]}++;
}
