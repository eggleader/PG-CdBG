#!/bin/perl
#usage: select all the superbubbles whose level=1 and containing all the samples
use strict;
use warnings;
my$sampnum = 800;
my$onestr = "1"; 
for(my$i = 1;$i<$sampnum;$i++){
	$onestr.="1";
}
open(IN,"superbubbleinfo.txt");
open(OUT,">selectsuperbubble.txt");
my$orgin = $/;
$/ = "end\n";
foreach my$block(<IN>){
	if($block =~ /level:(\d+)\s+.+bubblecolor:(\d+)[\s\d\w\W\S\D]+ branch number:(\d+)/){
		my($level,$bubcolor,$branch) = ($1,$2,$3);
#		print "$level;$branch\n";
		#if($level == 1 && $bubcolor eq $onestr && $branch > 2){
		if($level == 1){
		#if($level == 1 && $bubcolor eq $onestr){
	#		print "$level\t$bubcolor\n";
			print OUT "$block\n";
		}
		#if($level == 1 && $bubcolor ne $onestr){
		#	print $block;
		#}
	}
}
$/ = $orgin;
