#!/usr/bin/perl
use strict;
use warnings;
open(IN,"msaallsamples.txt");
#open(IN,"mymergeMSA.txt");
my@seqs;
my%base = (A=>1,C=>2,G=>3,T=>4,"-"=>0);
foreach my$line(<IN>){
	chomp $line;
	push(@seqs,$line);
}
my$len = length($seqs[0]);
my@varcount = (0,0,0);#novar,SNP,gap
my@vartype = (0,0,0,0,0);
for(my$i = 0;$i < $len;$i++){
	my@bases = (0,0,0,0,0);# -,A,C.G,T
	for(my$j = 0;$j < 800;$j++){
		my$seq = $seqs[$j];
		my$tmpbase = substr($seq,$i,1);
		my$id = $base{$tmpbase};
		$bases[$id]++;
	}
	if($bases[0] > 0){
		$varcount[2]++;
	}else{
		if($bases[1] == 800 ||$bases[2] == 800||$bases[3] == 800||$bases[4] == 800){
			$varcount[0]++;
		}else{
			$varcount[1]++;
		}
	}
	my$count = 0;
	for(my$i = 0;$i < 5;$i++){
		if($bases[$i] > 0){
			$count++;
		}
	}
	$vartype[$count-1]++;

}
print "var count: @varcount\n";
print "var type: @vartype\n";
