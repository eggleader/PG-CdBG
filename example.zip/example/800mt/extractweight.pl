#!/bin/perl
#usage:select all the weight information of superbubbles given by selectbubid.txt file 
#selectbubid.txt can be gotten by selectsuperbubble.txt(command:grep "Super" selectsuperbubble.txt|cut -d " " -f2 >selectbubid.txt)
use strict;
use warnings;
open(IN,"weightinfo.txt") or die "can't open weightinfo.txt";
my$idfile = $ARGV[0];
open(IN1,"$idfile")or die "cant open selectbubid.txt";
#open(IN1,"selectbubid.txt")or die "cant open selectbubid.txt";
#open(IN1,"selectbubid_proteincoding.txt")or die "cant open selectbubid.txt";
#open(IN1,"selectbubid_protein_rRNA.txt")or die "cant open selectbubid.txt";
#open(IN1,"selectbubid_protein_rRNA_tRNA.txt")or die "cant open selectbubid.txt";
my%selectid;
foreach my$id(<IN1>){
	chomp $id;
	$selectid{$id} = 1;
}
my$outfile = "weight_"."$idfile";
open(OUT,">$outfile");
#open(OUT,">mulweight.txt");

#open(OUT,">proteincoding_rRNA_tRNA_weight.txt");
my($bubid,@weight);
my$count = 0;
my$ifselect = 0;
foreach my$line(<IN>){
	chomp($line);
	if($line =~ /bubble:(\d+)/){
		$bubid = $1;
		if(exists($selectid{$bubid})){
			$ifselect = 1;}
		else{$ifselect = 0;}
		$count = 0;
#		print "bubble:$1\n";
	}
	else{
		if($ifselect == 1){
			if(!$weight[$count]){$weight[$count] = $line;}
			else{
#				print "$weight[$count]\n";
				my$preweight = $weight[$count];
#				print "$preweight\n";
				$weight[$count] = "$preweight $line";
			}
#			print "count: $count \nweight: $weight[$count]\nline: $line\n";
			$count++;
			
		
		}
	}
}
my$len = @weight;
for(my$i = 0;$i<$len;$i++){
	print OUT "$weight[$i]\n";
}
