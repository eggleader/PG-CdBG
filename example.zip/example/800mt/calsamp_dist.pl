#!/usr/bin/perl
use strict;
use warnings;
my$samp = 800;
open(IN,"weight_selectbubid.txt") or die "can't find weight_selectbubid.txt\n";
open(IN2,"newfilelist.txt") or die "can't find the filelist.txt";
my@filename = <IN2>;
my@data;
foreach my$line(<IN>){
	chomp$line;
	push(@data,$line)
	#my@info = split(/\t/,$line);	
}
my$value = $samp*$samp;
my@dist = (0.000000)x$value;
for(my$i = 0;$i < $samp-1;$i++){
	my$d1 = $data[$i];
	my@info1 = split(/\ /,$d1);
	my$len = @info1;
	my$a = 0;
	for(my$k = 0;$k < $len;$k++){
		$a += $info1[$k]**2;
	}
	for(my$j = $i+1;$j < $samp;$j++){
		my$d2 = $data[$j];
		my@info2 = split(/\ /,$d2);
		my$sum = 0;
		my$b = 0;
		my$inner = 0;
		for(my$k = 0;$k < $len;$k++){
			$sum+=($info1[$k]-$info2[$k])**2;
			$inner += $info1[$k]*$info2[$k];
			$b += $info2[$k]**2;
		}
		my$cos = $inner/(sqrt($a)*sqrt($b));
		#my$sqrt_dist = sprintf("%.6f",1-$cos);
		#my$sqrt_dist = sprintf("%.6f",sqrt($sum));
		my$sqrt_dist = sprintf("%.5f",log(sqrt($sum)+1));
		$dist[$i*$samp+$j] = $sqrt_dist;
		$dist[$j*$samp+$i] = $sqrt_dist;
	}
}
open(OUT,">euc.txt");
print OUT "    $samp\n";
my$isnewline = 1;
my$startid = 0;
for(my$i = 0;$i < $value;$i++){
	if($isnewline == 1){
		my$file = $filename[$startid];
		chomp $file;
		my@fileinfo = split(/\t/,$file);
		$startid++;
		print OUT "$fileinfo[2]     ";
		$isnewline = 0;
	}
	if($dist[$i] == 0){
		print OUT "  0.000000";
	}else{
		print OUT "  $dist[$i]";
	}
	if(($i+1) % $samp == 0){
		print OUT "\n";
		$isnewline = 1;
	}

}
